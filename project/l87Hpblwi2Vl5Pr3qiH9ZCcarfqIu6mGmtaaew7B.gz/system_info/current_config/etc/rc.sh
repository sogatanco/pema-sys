#!/bin/sh

# Copyright (c) 2021 Western Digital Corporation or its affiliates.
#
# This code is CONFIDENTIAL and a TRADE SECRET of Western Digital
# Corporation or its affiliates ("WD").  This code is protected
# under copyright laws as an unpublished work of WD.  Notice is
# for informational purposes only and does not imply publication.
#
# The receipt or possession of this code does not convey any rights to
# reproduce or disclose its contents, or to manufacture, use, or sell
# anything that it may describe, in whole or in part, without the
# specific written consent of WD.  Any reproduction or distribution
# of this code without the express written consent of WD is strictly
# prohibited, is a violation of the copyright laws, and may subject you
# to criminal prosecution.

export ROOTFS_LOG=/rootfs.log

/usr/sbin/pre_init.sh

property_service -s /etc &
pid="$!"
retry=0
while true
do
    MODEL=`getprop ro.model`
    [ -n "$MODEL" ] && break
    retry=$(expr $retry + 1)
    [ $retry -ge 5 ] && { echo "Fatal error: can't get model name" | busybox tee -a $ROOTFS_LOG; exit 1; }
    sleep 1
done
echo "initramfs: property_service(read-only) started, pid=$pid, retry=$retry, model=$MODEL" | busybox tee -a $ROOTFS_LOG

if [ "$MODEL" == "monarch2" ] || [ "$MODEL" == "yodaplus2" ]; then
    /usr/sbin/kamino_sata_part_init.sh
elif [ "$MODEL" == "pelican2" ]; then
    /usr/sbin/kamino_emmc_part_init.sh
else
    echo "Fatal error: unknown model name!" | busybox tee -a $ROOTFS_LOG
    exit 1
fi

/usr/sbin/post_init.sh

kill -TERM $pid
mkdir -p /data/property
property_service -d /data -s /etc &
pid="$!"
retry=0
while true
do
    setprop persist.wd.property_service.pid $pid
    [ "$(getprop persist.wd.property_service.pid)" == "$pid" ] && break
    retry=$(expr $retry + 1)
    [ $retry -ge 5 ] && { echo "Fatal error: unable to set property" | busybox tee -a $ROOTFS_LOG; exit 1; }
    sleep 1
done
echo "initramfs: property_service started, pid=$pid, retry=$retry" | busybox tee -a $ROOTFS_LOG

echo "initramfs: running realworld system_init" | busybox tee -a $ROOTFS_LOG
/usr/sbin/system_init
